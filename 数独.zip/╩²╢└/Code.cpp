#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<algorithm>
using namespace std;
typedef long long LL;
const int MAXN = 10010;
const int INF = 0x7777777f;
inline int read() {
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	return x*f;
}/*====================Template====================*/
int a[10][10], tot = 0;
int n[10][10], m[10][10], k[10][10];

void findSpace(int &X, int &Y) {
	for (int i = X; i <= 9; i++) {
		int j = (i == X) ? (Y) : (1);
		for ( ; j <= 9; j++) {
			if (a[i][j] == 0) {
				X = i;
				Y = j;
				return;
			}
		}
	}
}
bool check(int X, int Y, int V) {
	if (n[X][V]) return 0;
	if (m[Y][V]) return 0;
	if (k[(X-1)/3*3+(Y-1)/3+1][V]) return 0;
	return 1;
}
void addNum(int X, int Y, int V) {
	tot++;
	a[X][Y] = V;
	n[X][V] = m[Y][V] = k[(X-1)/3*3+(Y-1)/3+1][V] = 1;
}
void delNum(int X, int Y, int V) {
	tot--;
	a[X][Y] = 0;
	n[X][V] = m[Y][V] = k[(X-1)/3*3+(Y-1)/3+1][V] = 0;
}
bool work(int X, int Y) {
	if (tot == 81) return 1;
	findSpace(X, Y);
	for (int i = 1; i <= 9; i++) {
		if (check(X, Y, i)) {
			addNum(X, Y, i);
			if (work(X, Y)) return 1;
			delNum(X, Y, i);
		}
	}
	return 0;
}
void print() {
	for (int i = 1; i <= 9; i++) {
		for (int j = 1; j <= 9; j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}
}
int main(){
	freopen("data.txt", "r", stdin);
	freopen("ans.txt", "w", stdout);
	
	for (int i = 1; i <= 9; i++)
		for (int j = 1; j <= 9; j++) {
			a[i][j] = read();
			if (a[i][j]) addNum(i, j, a[i][j]);
		}
	
	work(1, 1);
	print();
	
	return 0;
}